import numpy as np
import torch
import torch.nn.functional as F
from torchvision import transforms
from PIL import Image
import math
to_tensor = transforms.Compose([transforms.ToTensor()])
#计算熵函数

def entropy(img):
    H, W = img.shape
    tmp = [0] * 256
    val = 0
    k = 0
    res = 0
    for i in range(H):
        for j in range(W):
            val = img[i][j]
            tmp[val] = float(tmp[val] + 1)
            k = float(k + 1)
    for i in range(len(tmp)):
        tmp[i] = float(tmp[i] / k)
    for i in range(len(tmp)):
        if (tmp[i] == 0):
            res = res
        else:
            res = float(res - tmp[i] * (math.log(tmp[i]) / math.log(2.0)))

    res_ = [0]*1
    res_[0] = res
    return torch.tensor(res_)


def entory_loss(tensor):
    B, C, W, H = tensor.shape
    ###先整一个tensor出来，后面的拼接上去
    img = tensor[0]
    img = transforms.ToPILImage()(img)
    img = np.array(img)
    entroy_batch = entropy(img)
    ################
    for i in range(B-1):
        img = tensor[i+1]
        img = transforms.ToPILImage()(img)
        img = np.array(img)
        entroy_batch_ = entropy(img)
        entroy_batch = torch.cat((entroy_batch, entroy_batch_), dim=0)

    ##################entory_batch为一个一个批次的信息熵，下面构建损失
    zeros = torch.zeros(B)
    loss = F.l1_loss(1/(entroy_batch+0.00000001), zeros)
    return loss


def STD(img):
    pad = 1
    H, W = img.shape
    std_res = [[0] * W] * H
    std_res = np.array(std_res)
    img = np.pad(img, (pad, pad), 'constant')
    for i in range(0, H, 1):
        for j in range(0, W, 1):
            center_x = i + pad
            center_y = j + pad
            std_res[i,j] = np.std(img[center_x-pad:center_x+pad, center_y-pad:center_y+pad])

    return std_res

def STD_weight(array1, array2):
    array1 = STD(array1)
    array2 = STD(array2)
    H, W = array1.shape
    map1 = [[0] * W] * H
    map2 = [[0] * W] * H
    for i in range(0, H, 1):
        for j in range(0, W, 1):
            if array1[i][j] > array2[i][j]:
                map1[i][j] = 1
                map2[i][j] = 0
                '''
                map1[i][j] = array1[i][j] / (array1[i][j] + array2[i][j])
                map2[i][j] = array2[i][j] / (array1[i][j] + array2[i][j])
                '''
            else:
                map1[i][j] = 0
                map2[i][j] = 1

    return torch.tensor(map1).unsqueeze(0), torch.tensor(map2).unsqueeze(0)
'''
if __name__ == '__main__':
    img = torch.randn(3, 1, 10, 10)
    xx = entory_loss(img)
    print(xx.shape)
    print(xx)
    '''


if __name__ == '__main__':
    img = Image.open(r'G:\咸鱼\全程辅导-兰州\datasets\Vis\1_2_23.jpg').convert('L')
    img1 = Image.open(r'G:\咸鱼\全程辅导-兰州\datasets\Inf\1_2_23.jpg').convert('L')
    img = np.array(img)
    img1 = np.array(img1)
    map_vis, map_inf = STD_weight(img, img1)
    print(map_vis.shape)
import torch
import torch.nn as nn
from torchinfo import summary
import torch.nn.functional as F
from models.fusion_manba import FusionMamba


class ResBlock2D(nn.Module):
    def __init__(self, dim, res_se_ratio):
        super().__init__()
        hidden_dim = int(res_se_ratio * dim)
        self.conv0 = nn.Conv2d(dim, hidden_dim, 3, 1, 1)
        self.conv1 = nn.Conv2d(hidden_dim, dim, 3, 1, 1)
        self.relu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        rs1 = self.relu(self.conv0(x))
        rs1 = self.conv1(rs1)
        rs = torch.add(x, rs1)
        return rs


class PixelShuffle(nn.Module):
    def __init__(self, dim, scale):
        super().__init__()
        self.upsamle = nn.Sequential(
            nn.Conv2d(dim, dim*(scale**2), 3, 1, 1, bias=False),
            nn.PixelShuffle(scale)
        )

    def forward(self, x):
        return self.upsamle(x)


class Up(nn.Module):
    def __init__(self, in_channels, out_channels, scale, upsample='default'):
        super().__init__()
        if upsample == 'bilinear':
            self.up = nn.Sequential(
                nn.Upsample(scale_factor=scale, mode='bilinear', align_corners=True),
                nn.Conv2d(in_channels, in_channels, 3, 1, 1, groups=in_channels),
                nn.Conv2d(in_channels, out_channels, 1, 1, 0),
                nn.LeakyReLU()
            )
        elif upsample == 'bicubic':
            self.up = nn.Sequential(
                nn.Upsample(scale_factor=scale, mode='bicubic', align_corners=True),
                nn.Conv2d(in_channels, in_channels, 3, 1, 1, groups=in_channels),
                nn.Conv2d(in_channels, out_channels, 1, 1, 0),
                nn.LeakyReLU()
            )
        elif upsample == 'pixelshuffle':
            self.up = nn.Sequential(
                PixelShuffle(in_channels, scale),
                nn.Conv2d(in_channels, in_channels, 3, 1, 1, groups=in_channels),
                nn.Conv2d(in_channels, out_channels, 1, 1, 0),
                nn.LeakyReLU()
            )
        else:
            self.up = nn.Sequential(
                nn.ConvTranspose2d(in_channels, out_channels, scale, scale, 0),
                nn.LeakyReLU()
            )
        self.conv = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, 3, 1, 1),
            nn.LeakyReLU()
        )

    def forward(self, x1, x2):
        x1 = self.up(x1)
        x = x1 + x2
        return self.conv(x)


class Down(nn.Module):
    def __init__(self, in_channels, out_channels, scale, downsample='default'):
        super().__init__()
        if downsample == 'maxpooling':
            self.down = nn.Sequential(
                nn.MaxPool2d(scale),
                nn.Conv2d(in_channels, out_channels, 1, 1, 0),
                nn.Conv2d(out_channels, out_channels, 3, 1, 1, groups=out_channels),
                nn.LeakyReLU()
            )
        else:
            self.down = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, scale, scale, 0),
                nn.LeakyReLU()
            )

    def forward(self, x):
        return self.down(x)


class Keep(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(Keep, self).__init__()
        self.conv = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        act = nn.LeakyReLU()
        x = self.conv(x)
        x = act(x)
        return x


class Stage(nn.Module):
    def __init__(self, in_channels, out_channels, H, W, scale=2, sample_mode='down'):
        super().__init__()
        self.fm = FusionMamba(in_channels, H, W)
        if sample_mode == 'down':
            self.sample = Down(in_channels, out_channels, scale)
        elif sample_mode == 'up':
            self.sample = Up(in_channels, out_channels, scale)

    def forward(self, pan, ms, pan_pre=None, ms_pre=None):
        pan, ms = self.fm(pan, ms)
        if pan_pre is None:
            pan_skip = pan
            ms_skip = ms
            pan = self.sample(pan)
            ms = self.sample(ms)
            return pan, ms, pan_skip, ms_skip
        else:
            pan = self.sample(pan, pan_pre)
            ms = self.sample(ms, ms_pre)
            return pan, ms

'''
起到一个融合+特征提取的作用
'''
class Stage_vif_encode(nn.Module):
    def __init__(self, in_channel, out_channel, H=64, W=64):
        super(Stage_vif_encode, self).__init__()
        self.fm = FusionMamba(out_channel, H, W)
        self.sample = Keep(in_channel=in_channel, out_channel=out_channel)

    def forward(self, vi, ir):
        vi = self.sample(vi)
        ir = self.sample(ir)
        vi, ir = self.fm(vi, ir)
        return vi, ir


class mamba_encoder_wo_pi(nn.Module):
    def __init__(self,in_channel, out_channel, H=64, W=64):
        super(mamba_encoder_wo_pi, self).__init__()
        self.mamba = Mamba_unit(dim=out_channel, H=H, W=W)
        self.conv = nn.Conv2d(in_channels=in_channel,out_channels=out_channel, kernel_size=3, stride=1, padding=1)

    def forward(self,vi, ir):
        vi, ir = self.conv(vi), self.conv(ir)
        vi, ir = self.mamba(vi), self.mamba(ir)
        return vi, ir


class mamba_decoder_wo_pi(nn.Module):
    def __init__(self,in_channel, out_channel, H=64, W=64):
        super(mamba_decoder_wo_pi, self).__init__()
        self.mamba = Mamba_unit(dim=out_channel, H=H, W=W)
        self.conv = nn.Conv2d(in_channels=in_channel,out_channels=out_channel, kernel_size=3, stride=1, padding=1)

    def forward(self,vi):
        vi = self.conv(vi)
        vi = self.mamba(vi)
        return vi



from models.fusion_manba import Mamba_unit
class Stage_vif_decode(nn.Module):
    def __init__(self, in_channel, out_channel, H=64, W=64):
        super(Stage_vif_decode, self).__init__()
        self.fm = Mamba_unit(in_channel,H,W)
        self.sample = Keep(in_channel=in_channel, out_channel=out_channel)

    def forward(self,x):
        x = self.fm(x)
        x = self.sample(x)
        return x

class U2Net(nn.Module):
    def __init__(self, dim, pan_dim, ms_dim, H=64, W=64, scale=4):
        super().__init__()

        self.raise_pan_dim = nn.Sequential(
            nn.Conv2d(pan_dim, dim, 3, 1, 1),
            nn.LeakyReLU()
        )
        self.raise_ms_dim = nn.Sequential(
            nn.Conv2d(ms_dim, dim, 3, 1, 1),
            nn.LeakyReLU()
        )
        self.to_hrms = nn.Sequential(
            nn.Conv2d(dim, dim, 3, 1, 1),
            nn.LeakyReLU(),
            nn.Conv2d(dim, ms_dim, 3, 1, 1)
        )

        # dimension for each stage
        dim0 = dim
        dim1 = int(dim0 * 2)
        dim2 = int(dim1 * 2)

        # main body
        self.stage0 = Stage(dim0, dim1, H, W, sample_mode='down')
        self.stage1 = Stage(dim1, dim2, H//2, W//2, sample_mode='down')
        self.stage2 = Stage(dim2, dim1, H//4, W//4, sample_mode='up')
        self.stage3 = Stage(dim1, dim0, H//2, W//2, sample_mode='up')
        self.stage4 = FusionMamba(dim0, H, W)

    def forward(self, ms, pan):
        pan = self.raise_pan_dim(pan)
        ms = self.raise_ms_dim(ms)

        # main body
        pan, ms, pan_skip0, ms_skip0 = self.stage0(pan, ms)
        pan, ms, pan_skip1, ms_skip1 = self.stage1(pan, ms)
        pan, ms = self.stage2(pan, ms, pan_skip1, ms_skip1)
        pan, ms = self.stage3(pan, ms, pan_skip0, ms_skip0)
        _, ms = self.stage4(pan, ms)

        output = self.to_hrms(ms)
        return output


if __name__ == '__main__':
    manba_model = Stage_vif_encode(in_channel=128, out_channel=64).cuda()
    img = torch.randn(1,128,64,64).cuda()
    for i in manba_model(img, img):
        print(i.shape)

import torch
import torch.nn as nn
import math
import torch.nn.functional as F
import torch.utils.checkpoint as checkpoint
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from einops import rearrange
import numbers
from LUT_models.model import DISA_decoder
#-----------------注意力机制融合------------------#
import torch
import torch.nn as nn


class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


class CoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)


    def forward(self, x):

        n, c, h, w = x[0].size()
        x0_h = self.pool_h(x[0])
        x0_w = self.pool_w(x[0]).permute(0, 1, 3, 2)
        x1_h = self.pool_h(x[1])
        x1_w = self.pool_w(x[1]).permute(0, 1, 3, 2)

        y = torch.cat([x0_h, x0_w, x1_w, x1_h], dim=2) #b,c,2w+2h,1
        y = self.conv1(y) #压缩 b,c/r,2w+2h,1
        y = self.bn1(y) #bn
        y = self.act(y) #激活

        x_h0, x_w0, x_h1, x_w1 = torch.split(y, [h, w, h, w], dim=2)
        x_w0 = x_w0.permute(0, 1, 3, 2)
        x_w1 = x_w1.permute(0, 1, 3, 2)

        a_h0 = self.conv_h(x_h0).sigmoid()
        a_w0 = self.conv_w(x_w0).sigmoid()

        a_h1 = self.conv_h(x_h1).sigmoid()
        a_w1 = self.conv_w(x_w1).sigmoid()

        out = x[0] * a_w0 * a_h0 + x[1] *a_w1 *a_h1

        return out

class cnn_encoder(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(cnn_encoder, self).__init__()
        self.fe1 = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)
        self.fe2 = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)
        self.fusion = CoordAtt(inp=dim_out, oup=dim_out)

    def forward(self, vi, ir):
        vi, ir = self.fe1(vi), self.fe2(ir)
        vi, ir = vi + self.fusion([vi,ir]), ir + self.fusion([vi,ir])
        return vi, ir



class cnn_encoder_wo_pi(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(cnn_encoder_wo_pi, self).__init__()
        self.fe1 = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)
        self.fe2 = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)

    def forward(self, vi, ir):
        act = nn.LeakyReLU()
        vi, ir = self.fe1(vi), self.fe1(ir)

        return act(vi), act(ir)



'''
class cnn_encoder(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(cnn_encoder, self).__init__()
        self.conv = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)

    def forward(self, vi, ir):
        act = nn.LeakyReLU()
        # vi, ir = vi + self.fusion([vi,ir]), ir + self.fusion([vi,ir])
        vi, ir = self.conv(vi), self.conv(ir)
        return act(vi), act(ir)
        '''


class cnn_decoder(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(cnn_decoder, self).__init__()
        self.fe = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        act = nn.LeakyReLU()
        x = self.fe(x)
        x = act(x)
        return x


class cnn_decoder_wo_pi(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(cnn_decoder_wo_pi, self).__init__()
        self.fe = nn.Conv2d(in_channels=dim_in, out_channels=dim_out, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        act = nn.LeakyReLU()
        x = self.fe(x)
        x = act(x)
        return x

if __name__ == '__main__':
    model = cnn_encoder(32, 64).cuda()
    img = torch.randn(1,32,40,40).cuda()
    for i in model(img, img):
        print(i.shape)
import math

import torch
from torch import nn
from torchvision import models
import torch.nn.functional as F


# 冻结网络层的参数
def set_parameter_requires_grad(model, feature_extracting):
    if feature_extracting:
        for param in model.parameters():
            param.required_grad = False



class VGG16net(nn.Module):
    def __init__(self, feature_extract=True, num_class=2):
        super(VGG16net, self).__init__()
        model = models.vgg16(pretrained=True)
        self.features = model.features
        set_parameter_requires_grad(self.features, feature_extract)
        self.avgpool = model.avgpool
        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 1024),
            nn.ReLU(),
            nn.Linear(1024, 1024),
            nn.ReLU(),
            nn.Linear(1024, num_class)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        # 改变tensor形状，拉伸成一维
        x = x.view(x.size(0), -1)
        out = self.classifier(x)
        return nn.Sigmoid()(out)

if __name__ == '__main__':
    model = VGG16net().cuda()
    image = torch.randn(1,3,64,64).cuda()
    print(model(image)[:,1], model(image)[:,0])
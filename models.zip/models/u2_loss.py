import torch
import torch.nn as nn
from models.vgg import vgg16
from models.utils import features_grad
from pytorch_msssim import ssim
import torch.nn.functional as F
c = 3500

class U2_LOSS(nn.Module):
    def __init__(self):
        super(U2_LOSS, self).__init__()
        self.feature_model = vgg16().cuda()
        self.feature_model.load_state_dict(torch.load('models/vgg16-397923af.pth'))
        self.loss_mse = nn.MSELoss(reduction='mean').cuda()

    def forward(self, vi, ir, fused_img):
        with torch.no_grad():
            feat_1 = torch.cat((vi, vi, vi), dim=1)
            feat_1 = self.feature_model(feat_1)
            feat_2 = torch.cat((ir, ir, ir), dim=1)
            feat_2 = self.feature_model(feat_2)

            for i in range(len(feat_1)):
                m1 = torch.mean(features_grad(feat_1[i]).pow(2), dim=[1, 2, 3])
                m2 = torch.mean(features_grad(feat_2[i]).pow(2), dim=[1, 2, 3])
                if i == 0:
                    w1 = torch.unsqueeze(m1, dim=-1)
                    w2 = torch.unsqueeze(m2, dim=-1)
                else:
                    w1 = torch.cat((w1, torch.unsqueeze(m1, dim=-1)), dim=-1)
                    w2 = torch.cat((w2, torch.unsqueeze(m2, dim=-1)), dim=-1)
            weight_1 = torch.mean(w1, dim=-1) / c
            weight_2 = torch.mean(w2, dim=-1) / c
            weight_list = torch.cat((weight_1.unsqueeze(-1), weight_2.unsqueeze(-1)), -1)
            weight_list = F.softmax(weight_list, dim=-1)

            loss_1 = weight_list[:, 0] * (1 - ssim(fused_img, vi, nonnegative_ssim=True)) \
                     + weight_list[:, 1] * (1 - ssim(fused_img, ir, nonnegative_ssim=True))
            loss_1 = torch.mean(loss_1)

            loss_2 = weight_list[:, 0] * self.loss_mse(fused_img, vi) \
                     + weight_list[:, 1] * self.loss_mse(fused_img, ir)
            loss_2 = torch.mean(loss_2)

            loss = loss_1 + 20 * loss_2

            return loss


from models.common import gradient
class GRAD_L1_LOSS(nn.Module):
    def __init__(self):
        super(GRAD_L1_LOSS, self).__init__()

    def forward(self,vis_y_image, inf_image, fused):
        loss_gard = F.l1_loss(gradient(fused), torch.max(gradient(vis_y_image), gradient(inf_image)))
        loss_l1 = F.l1_loss(fused, torch.max(vis_y_image, inf_image))
        return 50*loss_gard+10*loss_l1


if __name__ == '__main__':
    model = GRAD_L1_LOSS().cuda()
    img = torch.randn(2, 1, 8, 8).cuda()
    img1 = torch.randn(2, 1, 8, 8).cuda()
    print(model(img, img1, img))







import os

import torch
from torch import nn
from models.DBB import DiverseBranchBlock
from LUT_models.model import DISA
from models.common import reflect_conv, clamp
from LUT_models.model_base import CA
from PIL import Image
import matplotlib.pyplot as plt
from torch.utils import data
from torchvision import transforms

from models.common import RGB2YCrCb

def vision(original_tensor, type):
    _, c, _, _ = original_tensor.shape

    b = torch.nn.functional.adaptive_max_pool2d(original_tensor, (1, 1))
    k = b.cpu().clone()
    k = k.squeeze(0)
    list = []


    unloader = transforms.ToPILImage()
    image = original_tensor.cpu().clone()  # clone the tensor
    image = image.squeeze(0)  # remove the fake batch dimension
    for i in range(c):
        k = unloader(image[i])
        k.save(f'G:\闲鱼2024\ACGFusion\models\Vision_Feature\{type}\%d.jpg'%i)




class model(nn.Module):
    def __init__(self, deploy=False):
        super(model, self).__init__()
        self.deploy = deploy
        self.conv1 = DiverseBranchBlock(in_channels=2, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = DiverseBranchBlock(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = DiverseBranchBlock(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv4 = DiverseBranchBlock(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)

        self.conv5 = DiverseBranchBlock(in_channels=128, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv6 = DiverseBranchBlock(in_channels=64, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv7 = DiverseBranchBlock(in_channels=32, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv8 = DiverseBranchBlock(in_channels=16, out_channels=2, kernel_size=3, stride=1, padding=1)


    def forward(self, vi, ir):
        if self.deploy:
            self.conv1.switch_to_deploy()
            self.conv1.deploy = True
            self.conv2.switch_to_deploy()
            self.conv2.deploy = True
            self.conv3.switch_to_deploy()
            self.conv3.deploy = True
            self.conv4.switch_to_deploy()
            self.conv4.deploy = True
            self.conv5.switch_to_deploy()
            self.conv5.deploy = True
            self.conv6.switch_to_deploy()
            self.conv6.deploy = True
            self.conv7.switch_to_deploy()
            self.conv7.deploy = True
            self.conv8.switch_to_deploy()
            self.conv8.deploy = True
        f = torch.cat([vi, ir], dim=1)
        f1 = self.conv1(f)
        f2 = self.conv2(f1)
        f3 = self.conv3(f2)
        f4 = self.conv4(f3)
        f5 = self.conv5(f4)
        f6 = self.conv6(f5)
        f7 = self.conv7(f6)
        f8 = self.conv8(f7)
        map_vi = f8[:,:1,:,:]
        map_ir = f8[:,1:2,:,:]
        f = map_vi * vi + map_ir * ir
        return f, map_vi, map_ir


class model_wo_ddb(nn.Module):
    def __init__(self):
        super(model_wo_ddb, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=2, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)

        self.conv5 = nn.Conv2d(in_channels=128, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv6 = nn.Conv2d(in_channels=64, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv7 = nn.Conv2d(in_channels=32, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv8 = nn.Conv2d(in_channels=16, out_channels=2, kernel_size=3, stride=1, padding=1)

    def forward(self, vi, ir):
        f = torch.cat([vi, ir], dim=1)
        f1 = self.conv1(f)
        f2 = self.conv2(f1)
        f3 = self.conv3(f2)
        f4 = self.conv4(f3)
        f5 = self.conv5(f4)
        f6 = self.conv6(f5)
        f7 = self.conv7(f6)
        f8 = self.conv8(f7)
        map_vi = f8[:, :1, :, :]
        map_ir = f8[:, 1:2, :, :]
        f = map_vi * vi + map_ir * ir
        return f, map_vi, map_ir

class model_wo_map(nn.Module):
    def __init__(self):
        super(model_wo_map, self).__init__()
        self.conv1 = DiverseBranchBlock(in_channels=2, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv2 = DiverseBranchBlock(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv3 = DiverseBranchBlock(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv4 = DiverseBranchBlock(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)

        self.conv5 = DiverseBranchBlock(in_channels=128, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv6 = DiverseBranchBlock(in_channels=64, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv7 = DiverseBranchBlock(in_channels=32, out_channels=16, kernel_size=3, stride=1, padding=1)
        self.conv8 = DiverseBranchBlock(in_channels=16, out_channels=1, kernel_size=3, stride=1, padding=1)

    def forward(self, vi, ir):
        f = torch.cat([vi, ir], dim=1)
        f1 = self.conv1(f)
        f2 = self.conv2(f1)
        f3 = self.conv3(f2)
        f4 = self.conv4(f3)
        f5 = self.conv5(f4)
        f6 = self.conv6(f5)
        f7 = self.conv7(f6)
        f8 = self.conv8(f7)
        return f8




#-----------------用于计算特征的损失----------#
import torch
from torchvision import models
import torch.nn as nn

#------------这个分割网络只在训练代码中出现，因为是冻结的----------------#
#----------加载模型并返回，训练的时候不能一直去加载------------------#
def load_pretrained_sematic_network():
    model = models.segmentation.deeplabv3_resnet101(pretrained=True)
    last_conv_layer = model.classifier[4]
    # 修改最后一个卷积层，使其输出128个通道
    new_last_conv_layer = nn.Sequential(
        nn.Conv2d(256, 128, kernel_size=1, stride=1),
        nn.ReLU(inplace=True)
    )
    model.classifier[4] = new_last_conv_layer
    model.eval()
    return model


def pretrained_semantic_network(model, imgs):
    with torch.no_grad():
        return model(imgs)['out']

if __name__ == '__main__':
    img = torch.randn(2, 1, 640, 640).cuda()
    model = model(deploy=True).cuda()
    import time
    start = time.time()
    f, map_vi, map_ir = model(img, img)
    print(f.shape, map_vi.shape, map_ir.shape)
    ##0.19 0.24 0.21

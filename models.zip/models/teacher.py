import torch
from torch import nn
from models.DBB import DiverseBranchBlock
from models.common import reflect_conv
from models.transformer import Model
from models.enhance import FeatureRectifyModule
from LUT_models.model import DISA_decoder
from torchvision import transforms
from models.manba_blocks import Stage_vif_encode as mamba_e
from models.manba_blocks import Stage_vif_decode as mamba_d
from models.cross_modal_cnn import cnn_encoder, cnn_decoder
from models.cross_modal_transformer import trans_e, trans_d


def vision(original_tensor, type):
    _, c, _, _ = original_tensor.shape

    b = torch.nn.functional.adaptive_max_pool2d(original_tensor, (1, 1))
    k = b.cpu().clone()
    k = k.squeeze(0)
    list = []


    unloader = transforms.ToPILImage()
    image = original_tensor.cpu().clone()  # clone the tensor
    image = image.squeeze(0)  # remove the fake batch dimension
    for i in range(c):
        k = unloader(image[i])
        k.save(f'runs\{type}\%d.jpg'%i)


class encoder(nn.Module):
    def __init__(self):
        super(encoder, self).__init__()
        self.conv_in = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=16, stride=1, padding=1, kernel_size=3),
            nn.LeakyReLU()
        )

        self.trans1 = trans_e(16,32)
        self.trans2 = trans_e(32,64)
        self.trans3 = trans_e(64,128)

        self.conv1 = nn.Conv2d(in_channels=32*3, out_channels=32, stride=1, kernel_size=1, padding=0)

        self.mamba1 = mamba_e(16,32)
        self.mamba2 = mamba_e(32,64)
        self.mamba3 = mamba_e(64,128)
        self.conv2 = nn.Conv2d(in_channels=64 * 3, out_channels=64, stride=1, kernel_size=1, padding=0)

        self.cnn1 = cnn_encoder(16,32)
        self.cnn2 = cnn_encoder(32, 64)
        self.cnn3 = cnn_encoder(64, 128)
        self.conv3 = nn.Conv2d(in_channels=128 * 3, out_channels=128, stride=1, kernel_size=1, padding=0)


    def forward(self, vi, ir):
        vi, ir = self.conv_in(vi), self.conv_in(ir)



        vic, irc = self.cnn1(vi, ir)
        vit, irt = self.trans1(vi, ir)
        vim, irm = self.mamba1(vi, ir)
        vi, ir = self.conv1(torch.cat([vic, vit, vim],dim=1)), self.conv1(torch.cat([irc, irt, irm],dim=1))

        vic, irc = self.cnn2(vi, ir)
        vit, irt = self.trans2(vi, ir)
        vim, irm = self.mamba2(vi, ir)
        vi, ir = self.conv2(torch.cat([vic, vit, vim],dim=1)), self.conv2(torch.cat([irc, irt, irm],dim=1))

        vic, irc = self.cnn3(vi, ir)
        vit, irt = self.trans3(vi, ir)
        vim, irm = self.mamba3(vi, ir)
        vi, ir = self.conv3(torch.cat([vic, vit, vim],dim=1)), self.conv3(torch.cat([irc, irt, irm],dim=1))

        return vi, ir



class decoder(nn.Module):
    def __init__(self):
        super(decoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=128, stride=1, kernel_size=3, padding=1),
            nn.LeakyReLU()
        )

        self.trans1 = trans_d(128, 64)
        self.trans2 = trans_d(64, 32)
        self.trans3 = trans_d(32, 16)

        self.mamba1 = mamba_d(128, 64)
        self.mamba2 = mamba_d(64, 32)
        self.mamba3 = mamba_d(32, 16)

        self.cnn1 = cnn_decoder(128, 64)
        self.cnn2 = cnn_decoder(64, 32)
        self.cnn3 = cnn_decoder(32, 16)

        self.conv_out = nn.Sequential(
            nn.Conv2d(in_channels=16, out_channels=2, stride=1, kernel_size=3, padding=1)
        )

    def forward(self, vi, ir):
        x = self.conv(torch.cat([vi,ir],dim=1))

        x = self.trans1(x)+self.cnn1(x)+self.mamba1(x)
        x = self.trans2(x) + self.cnn2(x) + self.mamba2(x)
        x = self.trans3(x) + self.cnn3(x) + self.mamba3(x)

        x = self.conv_out(x)
        x = nn.Tanh()(x)/2+0.5

        return x

class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        self.e = encoder()
        self.d = decoder()

    def forward(self, vi, ir):
        vi_img, ir_img = vi, ir
        vi, ir =self.e(vi, ir)
        map=self.d(vi, ir)

        return vi_img*map[:,0:1,:,:]+ir_img*map[:,1:2,:,:], map[:,0:1,:,:], map[:,1:2,:,:]










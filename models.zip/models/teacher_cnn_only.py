import torch
from torch import nn
from models.DBB import DiverseBranchBlock
from models.common import reflect_conv
from models.transformer import Model
from models.enhance import FeatureRectifyModule
from LUT_models.model import DISA_decoder
from torchvision import transforms
from models.cross_modal_cnn import cnn_encoder, cnn_decoder
from models.cross_modal_transformer import trans_e, trans_d


class encoder(nn.Module):
    def __init__(self):
        super(encoder, self).__init__()
        self.conv_in = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=16, stride=1, padding=1, kernel_size=3),
            nn.LeakyReLU()
        )


        self.cnn1 = cnn_encoder(16,32)
        self.cnn2 = cnn_encoder(32, 64)
        self.cnn3 = cnn_encoder(64, 128)


    def forward(self, vi, ir):

        vi, ir = self.conv_in(vi), self.conv_in(ir)

        vic, irc = self.cnn1(vi, ir)
        vi, ir = vic, irc


        vic, irc = self.cnn2(vi, ir)
        vi, ir = vic, irc


        vic, irc = self.cnn3(vi, ir)
        vi, ir = vic, irc


        return vi, ir



class decoder(nn.Module):
    def __init__(self):
        super(decoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=128, stride=1, kernel_size=3, padding=1),
            nn.LeakyReLU()
        )

        self.cnn1 = cnn_decoder(128, 64)
        self.cnn2 = cnn_decoder(64, 32)
        self.cnn3 = cnn_decoder(32, 16)

        self.conv_out = nn.Sequential(
            nn.Conv2d(in_channels=16, out_channels=2, stride=1, kernel_size=3, padding=1)
        )

    def forward(self, vi, ir):

        x = self.conv(torch.cat([vi,ir],dim=1))

        x = self.cnn1(x)

        x = self.cnn2(x)

        x = self.cnn3(x)

        x = self.conv_out(x)
        x = nn.Tanh()(x) / 2 + 0.5

        return x



class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        self.e = encoder()
        self.d = decoder()

    def forward(self, vi, ir):
        vi_img, ir_img = vi, ir
        vi, ir =self.e(vi, ir)
        map=self.d(vi, ir)
        return vi_img*map[:,0:1,:,:]+ir_img*map[:,1:2,:,:], map[:,0:1,:,:], map[:,1:2,:,:]



'''
class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        self.conv = nn.Sequential(nn.Conv2d(in_channels=1, out_channels=16, stride=1, kernel_size=3, padding=1),
                                  nn.LeakyReLU())
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels=16, out_channels=32, stride=1, kernel_size=3, padding=1),
                                  nn.LeakyReLU())
        self.conv2 = nn.Sequential(nn.Conv2d(in_channels=32, out_channels=64, stride=1, kernel_size=3, padding=1),
                                  nn.LeakyReLU())
        self.conv3 = nn.Sequential(nn.Conv2d(in_channels=64, out_channels=128, stride=1, kernel_size=3, padding=1),
                                  nn.LeakyReLU())
        self.conv4 = nn.Sequential(nn.Conv2d(in_channels=128, out_channels=64, stride=1, kernel_size=3, padding=1),
                                  nn.LeakyReLU())
        self.conv5 = nn.Sequential(nn.Conv2d(in_channels=64, out_channels=32, stride=1, kernel_size=3, padding=1),
                                   nn.LeakyReLU())
        self.conv6 = nn.Sequential(nn.Conv2d(in_channels=32, out_channels=16, stride=1, kernel_size=3, padding=1),
                                   nn.LeakyReLU())
        self.conv7 = nn.Sequential(nn.Conv2d(in_channels=16, out_channels=2, stride=1, kernel_size=3, padding=1),
                                   nn.LeakyReLU())


    def forward(self, vi, ir):
        vi, ir =
        '''



if __name__ == '__main__':
    model_ = model().cuda()
    img = torch.randn(1,1,10,10).cuda()
    for i in model_(img, img):
        print(i.shape)










import torch
from torch import nn
from models.DBB import DiverseBranchBlock
from models.common import reflect_conv
from models.transformer import Model
from models.enhance import FeatureRectifyModule
from LUT_models.model import DISA_decoder
from torchvision import transforms
from models.manba_blocks import Stage_vif_encode as mamba_e
from models.manba_blocks import Stage_vif_decode as mamba_d
from models.cross_modal_cnn import cnn_encoder, cnn_decoder
from models.cross_modal_transformer import trans_e, trans_d


class encoder(nn.Module):
    def __init__(self):
        super(encoder, self).__init__()
        self.conv_in = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=16, stride=1, padding=1, kernel_size=3),
            nn.LeakyReLU()
        )

        self.trans1 = trans_d(16,32)
        self.trans2 = trans_d(32,64)
        self.trans3 = trans_d(64,128)



    def forward(self, vi, ir):
        vi, ir = self.conv_in(vi), self.conv_in(ir)


        vi, ir = self.trans1(vi), self.trans1(ir)

        vi, ir = self.trans2(vi), self.trans2(ir)

        vi, ir = self.trans3(vi), self.trans3(ir)

        return vi, ir



class decoder(nn.Module):
    def __init__(self):
        super(decoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=128, stride=1, kernel_size=3, padding=1),
            nn.LeakyReLU()
        )

        self.trans1 = trans_d(128, 64)
        self.trans2 = trans_d(64, 32)
        self.trans3 = trans_d(32, 16)


        self.conv_out = nn.Sequential(
            nn.Conv2d(in_channels=16, out_channels=2, stride=1, kernel_size=3, padding=1)
        )

    def forward(self, vi, ir):
        x = self.conv(torch.cat([vi,ir],dim=1))

        x = self.trans1(x)
        x = self.trans2(x)
        x = self.trans3(x)

        x = self.conv_out(x)
        x = nn.Tanh()(x) / 2 + 0.5

        return x

from models.common import clamp
class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        self.e = encoder()
        self.d = decoder()

    def forward(self, vi, ir):
        vi_img, ir_img = vi, ir
        vi, ir =self.e(vi, ir)
        map=self.d(vi, ir)
        map = clamp(map)
        return vi_img*map[:,0:1,:,:]+ir_img*map[:,1:2,:,:], map[:,0:1,:,:], map[:,1:2,:,:]










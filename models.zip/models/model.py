import torch
from torch import nn
from models.DBB import DiverseBranchBlock
from models.common import reflect_conv
from models.transformer import Model
from models.enhance import FeatureRectifyModule
from LUT_models.model import DISA_decoder
from torchvision import transforms

def vision(original_tensor, type):
    _, c, _, _ = original_tensor.shape

    b = torch.nn.functional.adaptive_max_pool2d(original_tensor, (1, 1))
    k = b.cpu().clone()
    k = k.squeeze(0)
    list = []


    unloader = transforms.ToPILImage()
    image = original_tensor.cpu().clone()  # clone the tensor
    image = image.squeeze(0)  # remove the fake batch dimension
    for i in range(c):
        k = unloader(image[i])
        k.save(f'G:\闲鱼2024\ACGFusion\models\Vision_Feature\{type}\%d.jpg'%i)

##端到端网络的编码器
class encoder(nn.Module):
    def __init__(self):
        super(encoder, self).__init__()
        self.conv1 = DISA_decoder(inchannel=1, outchannel=16)
        self.conv2 = DISA_decoder(inchannel=16, outchannel=32)
        self.conv3 = DISA_decoder(inchannel=32, outchannel=64)
        self.conv4 = DISA_decoder(inchannel=64, outchannel=128)

        ###定义transformer部分
        self.TF1 = Model(in_channel=1, out_channel=16)
        self.TF2 = Model(in_channel=16, out_channel=32)
        self.TF3 = Model(in_channel=32, out_channel=64)
        self.TF4 = Model(in_channel=64, out_channel=128)

        self.fr1 = FeatureRectifyModule(dim=16)
        self.fr2 = FeatureRectifyModule(dim=32)
        self.fr3 = FeatureRectifyModule(dim=64)
        self.fr4 = FeatureRectifyModule(dim=128)

    def forward(self, vi, ir):
        vi, ir = self.conv1(vi), self.TF1(ir)
        vi, ir = self.fr1(vi, ir)
        vi, ir = self.conv2(vi), self.TF2(ir)
        vi, ir = self.fr2(vi, ir)
        vi, ir = self.conv3(vi), self.TF3(ir)
        vi, ir = self.fr3(vi, ir)
        vi, ir = self.conv4(vi), self.TF4(ir)
        vi, ir = self.fr4(vi, ir)
        return vi, ir



#############################
class decoder(nn.Module):
    def __init__(self):
        super(decoder, self).__init__()
        self.conv1 = DISA_decoder(inchannel=128, outchannel=64)
        self.conv2 = DISA_decoder(inchannel=64, outchannel=32)
        self.conv3 = DISA_decoder(inchannel=32, outchannel=16)
        self.conv4 = DISA_decoder(inchannel=16, outchannel=1)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        return x




class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        self.encoder = encoder()
        self.conv = reflect_conv(in_channels=256, out_channels=128, kernel_size=3, stride=1, pad=1)
        self.decoder_vi = decoder()
        self.decoder_ir = decoder()


    def forward(self,vi, ir):
        '''
        return f, vi_map and ir_map
        '''
        vi_img = vi
        ir_img = ir



        vi, ir = self.encoder(vi, ir)


        f = torch.cat([vi, ir], dim=1)
        f = self.conv(f)
        map_vi = self.decoder_vi(f)
        map_ir = self.decoder_ir(f)

        f_img = map_vi * vi_img + map_ir * ir_img
        return f_img, map_vi, map_ir



if __name__ == '__main__':
    image = torch.randn(2,1,8,8).cuda()
    image1 = torch.randn(2, 1, 8, 8).cuda()

    model = model().cuda()
    f_img, map1, map2 = model(image, image)
    print(map1 - map2)
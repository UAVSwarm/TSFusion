import math
import torch
import numpy as np
import torch.nn as nn
from einops import rearrange
import torch.nn.functional as F
from manba_base.mamba_simple import Mamba
from mamba_ssm.ops.triton.layernorm import RMSNorm, layer_norm_fn, rms_norm_fn


class SingleMambaBlock(nn.Module):
    def __init__(self, dim, H, W):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        # self.norm1 = nn.LayerNorm(dim)
        self.block = Mamba(dim, expand=1, d_state=8, bimamba_type='v6', if_devide_out=True, use_norm=True, input_h=H, input_w=W)

    def forward(self, input):
        # input: (B, N, C)
        skip = input
        input = self.norm(input)
        output = self.block(input)
        # output = self.norm1(output)
        return output + skip





class CrossMambaBlock(nn.Module):
    def __init__(self, dim, H, W):
        super().__init__()
        self.norm0 = nn.LayerNorm(dim)
        self.norm1 = nn.LayerNorm(dim)
        # self.norm2 = nn.LayerNorm(dim)
        self.block = Mamba(dim, expand=1, d_state=8, bimamba_type='v7',
                           if_devide_out=True, use_norm=True, input_h=H, input_w=W)

    def forward(self, input0, input1):
        # input0: (B, N, C) | input1: (B, N, C)
        skip = input0
        input0 = self.norm0(input0)
        input1 = self.norm1(input1)
        output = self.block(input0, extra_emb=input1)
        # output = self.norm2(output)
        return output + skip


class FusionMamba(nn.Module):
    def __init__(self, dim, H, W, depth=1):
        super().__init__()
        self.spa_mamba_layers = nn.ModuleList([])
        self.spe_mamba_layers = nn.ModuleList([])
        for _ in range(depth):
            self.spa_mamba_layers.append(SingleMambaBlock(dim, H, W))
            self.spe_mamba_layers.append(SingleMambaBlock(dim, H, W))
        self.spa_cross_mamba = CrossMambaBlock(dim, H, W)
        self.spe_cross_mamba = CrossMambaBlock(dim, H, W)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, pan, ms):
        b, c, h, w = pan.shape
        pan = rearrange(pan, 'b c h w -> b (h w) c', h=h, w=w)
        ms = rearrange(ms, 'b c h w -> b (h w) c', h=h, w=w)
        for spa_layer, spe_layer in zip(self.spa_mamba_layers, self.spe_mamba_layers):
            pan = spa_layer(pan)
            ms = spe_layer(ms)
        spa_fusion = self.spa_cross_mamba(pan, ms)
        spe_fusion = self.spe_cross_mamba(ms, pan)
        fusion = self.out_proj((spa_fusion + spe_fusion) / 2)
        pan = rearrange(pan, 'b (h w) c -> b c h w', h=h, w=w)
        ms = rearrange(ms, 'b (h w) c -> b c h w', h=h, w=w)
        output = rearrange(fusion, 'b (h w) c -> b c h w', h=h, w=w)
        return pan+output, ms + output



class Mamba_unit(nn.Module):
    def __init__(self, dim, H, W):
        super(Mamba_unit, self).__init__()
        self.singlemamba = SingleMambaBlock(dim ,H, W)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, x):
        b, c, h, w = x.shape
        x = rearrange(x, 'b c h w -> b (h w) c', h=h, w=w)
        x = self.singlemamba(x)
        x = self.out_proj(x)
        x = rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)
        return x



#---------------------写一个跨模态的mamba----------------#

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()
        self.register_buffer()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


#------------跨模态融合mamba---------------#
class cross_model_MambaBlocks(nn.Module):
    def __init__(self, dim, H, W):
        super().__init__()
        self.singlemamba1 = SingleMambaBlock(dim, 2*H, W)
        self.singlemamba2 = SingleMambaBlock(dim, H, 2*W)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, vis, inf):
        skip_vis = vis
        skip_inf = inf
        #-------------第一次，将两个特征图，竖着放在一起,b,c,h,w-----------------#
        b,c,h,w = vis.shape
        fuse1 = torch.cat([vis, inf],dim=2) # b, c, h*2, w
        #print(fuse1.shape)
        fuse1 = rearrange(fuse1, 'b c h w -> b (h w) c')
        fuse1 = self.singlemamba1(fuse1)
        fuse1 = self.out_proj(fuse1)
        fuse1 = rearrange(fuse1, 'b (h w) c -> b c h w', h=h*2)
        #-----------------第二次，将两个特征图，横着放一起-------------------#
        fuse2 = torch.cat([vis,inf],dim=3) #b,c,h,2*w
        fuse2 = rearrange(fuse2, 'b c h w -> b (h w) c')
        fuse2 = self.singlemamba2(fuse2)
        fuse2 = rearrange(fuse2, 'b (h w) c -> b c h w', w=2*w)
        #--------------第三次，把两个不同方向融合的特征图，再次，组合，不同方向再融一次
        #------------对两个融合后的特征，都拆分开，学多光谱检测那个----------------#
        vi_fuse1, ir_fuse1 = torch.chunk(fuse1, 2, dim=2) #都是b,c,w,h
        vi_fuse2, ir_fuse2 = torch.chunk(fuse2, 2, dim=3)
        return skip_vis+vi_fuse1+vi_fuse2, skip_inf+ir_fuse1+ir_fuse2



if __name__ == '__main__':
    model = cross_model_MambaBlocks(dim=3, H=64, W=64).cuda()
    vis_feature = torch.randn(1,3,64,64).cuda()
    for i in model(vis_feature, vis_feature):
        print(i.shape)
